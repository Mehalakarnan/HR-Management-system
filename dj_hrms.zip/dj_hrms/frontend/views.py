from django.contrib.auth import authenticate, login, logout
from django.shortcuts import redirect, render
from django.contrib import messages  # Import messages from Django

def customer_login(request):
    if request.method == 'POST':
        username = request.POST.get('email-username')  # Adjusted for your form input name
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid username or password. Please enter correct username and password.')
            # If authentication fails, render the login page again with error message
            return render(request, 'frontend/login.html')

    # If request method is not POST (GET request), render the login page
    return render(request, 'frontend/login.html')

def customer_logout(request):
    logout(request)
    return redirect('home')
