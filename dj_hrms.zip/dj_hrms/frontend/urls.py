from django.urls import path

from backend.views import Dashboard
from .views import customer_login, customer_logout

urlpatterns = [
    # Auth
    path('', customer_login, name='customer_login'),  # Render login page
    path('login', customer_login, name='customer_login'),  # Handle login POST request

    # Logout
    path('logout', customer_logout, name='customer_logout'),
    path('dashboard/', Dashboard.as_view(), name='dashboard'),

]