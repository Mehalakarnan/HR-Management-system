from django.db import models
from django.contrib.auth.models import User

class Department(models.Model):
    id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length=100)
    manager = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='managed_departments')
    description = models.TextField(blank=True)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'department'

class Employee(models.Model):
    id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length=100, blank=True, null=True)
    department = models.ForeignKey(Department, on_delete=models.SET_NULL, null=True, related_name='employees')
    email = models.EmailField()
    phone_number = models.CharField(max_length=15, blank=True)
    address = models.TextField(blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    date_joined = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'employee'

class Leave(models.Model):
    id = models.BigAutoField(primary_key=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='leave_requests')
    start_date = models.DateField()
    end_date = models.DateField()
    reason = models.TextField()
    status_choices = [
        ('PENDING', 'Pending'),
        ('APPROVED', 'Approved'),
        ('REJECTED', 'Rejected'),
    ]
    status = models.CharField(max_length=10, choices=status_choices, default='PENDING')

    def __str__(self):
        return f"{self.employee} - {self.start_date} to {self.end_date}"

    class Meta:
        db_table = 'leave'

class Attendance(models.Model):
    id = models.BigAutoField(primary_key=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='attendances')
    date = models.DateField()
    time_choices = [
        ('9,o AM', '9,o AM'),
        ('10,o AM', '10,o AM'),
        ('11,o AM', '11,o AM'),
        ('12,o PM', '12,o PM'),
        ('1,o PM', '1,o PM'),
        ('2,o PM', '2,o PM'),
        ('3,o PM', '3,o PM'),
        ('4,o PM', '4,o PM'),
    ]
    time_in = models.CharField(max_length=10, choices=time_choices, blank=True, null=True)
    time_out = models.CharField(max_length=10, choices=time_choices, blank=True, null=True)
    reason = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"{self.employee} - {self.date}"

    class Meta:
        db_table = 'attendance'

class Payroll(models.Model):
    id = models.BigAutoField(primary_key=True)
    employee = models.OneToOneField(Employee, on_delete=models.CASCADE, related_name='payroll')
    salary = models.DecimalField(max_digits=10, decimal_places=2)
    deductions = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    bonuses = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    def __str__(self):
        return f"{self.employee} - Payroll"

    class Meta:
        db_table = 'payroll'
