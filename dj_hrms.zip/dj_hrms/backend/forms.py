from django import forms

from backend.models import Department, Employee, Leave, Attendance, Payroll
from tempus_dominus.widgets import DateTimePicker

#-----------Department-----------#
class DepartmentForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(DepartmentForm, self).__init__(*args, **kwargs)

        self.fields['name'].widget.attrs.update({'class': 'form-control'})
        self.fields['manager'].widget.attrs.update({'class': 'form-control'})
        self.fields['description'].widget.attrs.update({'class': 'form-control'})

    class Meta:
        model = Department
        fields = ('name', 'manager', 'description')

#-----------Employee-----------#
class EmployeeForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(EmployeeForm, self).__init__(*args, **kwargs)

        self.fields['name'].widget.attrs.update({'class': 'form-control'})
        self.fields['department'].widget.attrs.update({'class': 'form-control'})
        self.fields['email'].widget.attrs.update({'class': 'form-control'})
        self.fields['phone_number'].widget.attrs.update({'class': 'form-control'})
        self.fields['address'].widget.attrs.update({'class': 'form-control'})
        self.fields['date_of_birth'].widget.attrs.update({'class': 'form-control datepicker'})

    class Meta:
        model = Employee
        fields = ('name', 'department', 'email', 'phone_number', 'address', 'date_of_birth')

#-----------Leave-----------#
class LeaveForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(LeaveForm, self).__init__(*args, **kwargs)

        self.fields['employee'].widget.attrs.update({'class': 'form-control'})
        self.fields['start_date'].widget.attrs.update({'class': 'form-control'})
        self.fields['end_date'].widget.attrs.update({'class': 'form-control'})
        self.fields['reason'].widget.attrs.update({'class': 'form-control'})
        self.fields['status'].widget.attrs.update({'class': 'form-control'})

    class Meta:
        model = Leave
        fields = ('employee', 'start_date', 'end_date', 'reason', 'status')

#-----------Attendance-----------#
class AttendanceForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(AttendanceForm, self).__init__(*args, **kwargs)

        self.fields['employee'].widget.attrs.update({'class': 'form-control'})
        self.fields['date'].widget.attrs.update({'class': 'form-control datepicker'})
        self.fields['time_in'].widget.attrs.update({'class': 'form-control'})
        self.fields['time_out'].widget.attrs.update({'class': 'form-control'})
        self.fields['reason'].widget.attrs.update({'class': 'form-control'})

    class Meta:
        model = Attendance
        fields = ('employee', 'date', 'time_in', 'time_out', 'reason')


# -----------Payroll-----------#
class PayrollForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(PayrollForm, self).__init__(*args, **kwargs)

        self.fields['employee'].widget.attrs.update({'class': 'form-control'})
        self.fields['salary'].widget.attrs.update({'class': 'form-control'})
        self.fields['deductions'].widget.attrs.update({'class': 'form-control'})
        self.fields['bonuses'].widget.attrs.update({'class': 'form-control'})

    class Meta:
        model = Payroll
        fields = ('employee', 'salary', 'deductions', 'bonuses')