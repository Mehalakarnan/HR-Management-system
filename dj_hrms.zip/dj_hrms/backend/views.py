from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, UpdateView, DeleteView, TemplateView

from backend.forms import LeaveForm, AttendanceForm, PayrollForm, EmployeeForm, DepartmentForm
from backend.models import Department, Employee, Leave, Attendance, Payroll



# --------Dashboard--------#
class Dashboard(TemplateView):

    template_name = "dashboard.html"

    def get_context_data(self,*args, **kwargs):
        context = super(Dashboard, self).get_context_data(*args, **kwargs)
        context['title'] = "Dashboard"
        context['department'] = Department.objects.all().count
        context['employee'] = Employee.objects.all().count
        context['attendance'] = Attendance.objects.all().count
        context['payroll'] = Payroll.objects.all().count

        return context

# --------Department--------#

class DepartmentList(ListView):

    model = Department
    template_name = "backend/department/list.html"


class DepartmentCreate(CreateView):

    model = Department
    template_name = "backend/department/create.html"
    form_class = DepartmentForm
    success_url = reverse_lazy('department_list')

class DepartmentUpdate(UpdateView):

    model = Department
    template_name = "backend/department/update.html"
    form_class = DepartmentForm
    success_url = reverse_lazy('department_list')

class DepartmentDelete(DeleteView):

    model = Department
    template_name = "backend/department/delete.html"
    success_url = reverse_lazy('department_list')

# --------Employee--------#

class EmployeeList(ListView):

    model = Employee
    template_name = "backend/employee/list.html"


class EmployeeCreate(CreateView):

    model = Employee
    template_name = "backend/employee/create.html"
    form_class = EmployeeForm
    success_url = reverse_lazy('employee_list')

class EmployeeUpdate(UpdateView):

    model = Employee
    template_name = "backend/employee/update.html"
    form_class = EmployeeForm
    success_url = reverse_lazy('employee_list')


class EmployeeDelete(DeleteView):

    model = Employee
    template_name = "backend/employee/delete.html"
    success_url = reverse_lazy('employee_list')

# --------Leave--------#

class LeaveList(ListView):

    model = Leave
    template_name = "backend/leave/list.html"


class LeaveCreate(CreateView):

    model = Leave
    template_name = "backend/leave/create.html"
    form_class = LeaveForm
    success_url = reverse_lazy('leave_list')

class LeaveUpdate(UpdateView):

    model = Leave
    template_name = "backend/leave/update.html"
    form_class = LeaveForm
    success_url = reverse_lazy('leave_list')


class LeaveDelete(DeleteView):

    model = Leave
    template_name = "backend/leave/delete.html"
    success_url = reverse_lazy('leave_list')

# --------Attendance--------#

class AttendanceList(ListView):

    model = Attendance
    template_name = "backend/attendance/list.html"


class AttendanceCreate(CreateView):

    model = Attendance
    template_name = "backend/attendance/create.html"
    form_class = AttendanceForm
    success_url = reverse_lazy('attendance_list')

class AttendanceUpdate(UpdateView):

    model = Leave
    template_name = "backend/attendance/update.html"
    form_class = AttendanceForm
    success_url = reverse_lazy('attendance_list')


class AttendanceDelete(DeleteView):

    model = Attendance
    template_name = "backend/attendance/delete.html"
    success_url = reverse_lazy('attendance_list')

# --------Payroll--------#

class PayrollList(ListView):

    model = Payroll
    template_name = "backend/payroll/list.html"


class PayrollCreate(CreateView):

    model = Payroll
    template_name = "backend/payroll/create.html"
    form_class = PayrollForm
    success_url = reverse_lazy('payroll_list')

class PayrollUpdate(UpdateView):

    model = Payroll
    template_name = "backend/payroll/update.html"
    form_class = PayrollForm
    success_url = reverse_lazy('payroll_list')


class PayrollDelete(DeleteView):

    model = Payroll
    template_name = "backend/attendance/delete.html"
    success_url = reverse_lazy('payroll_list')