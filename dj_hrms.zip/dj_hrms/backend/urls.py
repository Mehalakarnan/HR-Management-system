from django.urls import path

from backend.views import DepartmentList, DepartmentCreate, DepartmentUpdate, DepartmentDelete, EmployeeList, \
    EmployeeCreate, EmployeeUpdate, EmployeeDelete, LeaveList, LeaveCreate, LeaveUpdate, LeaveDelete, AttendanceList, \
    AttendanceCreate, AttendanceUpdate, AttendanceDelete, PayrollList, PayrollCreate, PayrollUpdate, PayrollDelete, \
    Dashboard

urlpatterns = [

    # dashboard
    path('', Dashboard.as_view()),

    # department
    path('department/', DepartmentList.as_view(), name='department_list'),
    path('department/create/', DepartmentCreate.as_view(), name='department_create'),
    path('department/update/<pk>/', DepartmentUpdate.as_view(), name='department_update'),
    path('department/delete/<pk>/', DepartmentDelete.as_view(), name='department_delete'),

    # employee
    path('employee/', EmployeeList.as_view(), name='employee_list'),
    path('employee/create/', EmployeeCreate.as_view(), name='employee_create'),
    path('employee/update/<pk>/', EmployeeUpdate.as_view(), name='employee_update'),
    path('employee/delete/<pk>/', EmployeeDelete.as_view(), name='employee_delete'),

    # leave
    path('leave/', LeaveList.as_view(), name='leave_list'),
    path('leave/create/', LeaveCreate.as_view(), name='leave_create'),
    path('leave/update/<pk>/', LeaveUpdate.as_view(), name='leave_update'),
    path('leave/delete/<pk>/', LeaveDelete.as_view(), name='leave_delete'),

    # attendance
    path('attendance/', AttendanceList.as_view(), name='attendance_list'),
    path('attendance/create/', AttendanceCreate.as_view(), name='attendance_create'),
    path('attendance/update/<pk>/', AttendanceUpdate.as_view(), name='attendance_update'),
    path('attendance/delete/<pk>/', AttendanceDelete.as_view(), name='attendance_delete'),

    # payroll
    path('payroll/', PayrollList.as_view(), name='payroll_list'),
    path('payroll/create/', PayrollCreate.as_view(), name='payroll_create'),
    path('payroll/update/<pk>/', PayrollUpdate.as_view(), name='payroll_update'),
    path('payroll/delete/<pk>/', PayrollDelete.as_view(), name='payroll_delete'),

]